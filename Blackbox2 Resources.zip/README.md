All music, textures and models by samurai_worf
(Some textures have been created by modifying and mixing minecrafts default textures)

The sound effects are taken from Pixabay (and edited by samurai_worf):\

turn_gears: gear-spinning-loop - https://pixabay.com/sound-effects/gear-spinning-loop-6981/

boom: BOOM Geomorphism | Cinematic Trailer Sound Effects by SUBMORITY - https://pixabay.com/sound-effects/boom-geomorphism-cinematic-trailer-sound-effects-123876/

open_valve: Flowing Water Loop 1 by floraphonic - https://pixabay.com/sound-effects/flowing-water-loop-1-183953/

train: Train - Railroad - Traffic Sound by JuliusH - https://pixabay.com/sound-effects/train-railroad-traffic-sound-8002/
